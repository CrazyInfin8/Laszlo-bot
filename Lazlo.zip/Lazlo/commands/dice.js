rand = require(`${__projdir}/util/rand.js`);

module.exports = {
    'name': 'dice',
    'description': 'Randomly generates a number from 1 to the number of faces (defaults to 6)',
    'syntax': '$ dice(faces)',
    'parameters': {'faces':'the number of faces to roll for'},
    'test': /^ ?\$ ?dice(?: ?\( ?\d+ ?\))? ?$/i,
    'function': (msg, bot) => {
        param1 = msg.content.match(/^ ?\$ ?dice(?: ?\( ?(\d+) ?\))? ?$/i)[1]
        if (!param1) {
            return msg.reply(`using 6 sided die\nresults: ${rand.randInt(1,6)}`)
        } else {
            param1 = Number(param1)
            if(param1 < 3) {
                return msg.reply(`Number too small… using 6 sided die\nresults: ${rand.randInt(1,6)}`)
            } else {
                return msg.reply(`rolling ${param1} sided die\nresults: ${rand.randInt(1,param1)}`);
            }
        }
    }
}